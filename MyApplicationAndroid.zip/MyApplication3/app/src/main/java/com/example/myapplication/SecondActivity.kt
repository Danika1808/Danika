package com.example.myapplication

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_second.*


class SecondActivity : AppCompatActivity() {
    private lateinit var pref: SharedPreferences

    private val APP_PREFERENCES = "mysettings"
    val APP_PREFERENCES_LogCheck = "LogCheck"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pref = getSharedPreferences(APP_PREFERENCES, MODE_PRIVATE)
        if (pref.getBoolean(APP_PREFERENCES_LogCheck, false))
            setContentView(R.layout.activity_main)
        else
            setContentView(R.layout.activity_second)
    }
    fun LogIn(view: View) {
        val logInRegex = "[a-zA-Z0-9]+@[a-zA-Z0-9]+\\.[a-zA-Z0-9]+".toRegex()
        val passwordRegex = "^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{6,}\$".toRegex()
        if ((username_et.text.toString().matches(logInRegex) && username_et.text.toString().equals("danikavasilev@gmail.com")) ||
            (password_et.text.toString().matches(passwordRegex) && password_et.text.toString().equals("Kekmlg1337"))){
            val editor = pref.edit()
            editor.putBoolean( APP_PREFERENCES_LogCheck, true)
            editor.apply()
            intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        else {
            val myToast =
                Toast.makeText(this, "Uncorrect Password or e-mail", Toast.LENGTH_SHORT)
            myToast.show()
        }
    }

    fun LogOut(view: View) {
        val editor = pref.edit()
        editor.putBoolean( APP_PREFERENCES_LogCheck, false)
        editor.apply()
        val intent =  Intent(this, SecondActivity::class.java)
        startActivity(intent)
    }
}
